***********************************
Mohammadamin Sheikhtaheri - 0930853
Samuel Tracz - 0927451
Nov. 15, 2019

CIS*3210 - Assignment 2
README.txt
***********************************

***********
Compilation
***********

	make saw

*********
Execution
*********

	./saw 10 0.2 0.3 1000
	
*****************
Remove Executable
*****************

	make clean
	
*********
Zip Files
*********

	make zip
