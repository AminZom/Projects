*************************
Mohammadamin Sheikhtaheri
0930853
CIS4150 Lab 1
September 27, 2019
*************************

How to run:
***********
First, please turn the file into an executable using "chmod +x myLab.sh"
To execute, please use ./myLab.sh <testFiles>, and replace "<testFiles>" with the names of the test files you wish to run.

Things to Note:
***************
Please use sh or ./ when executing the file, when using bash, the colour coded echo statements come out all weird in the terminal.
It does still say pass or fail, just with some giberish next to it.
