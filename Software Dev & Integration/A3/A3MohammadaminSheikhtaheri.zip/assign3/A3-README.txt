*******************************************
Mohammadamin Sheikhtaheri           0930853
CIS2750         			   Assignment 3
Monday Mar 19, 2018
*******************************************

***********
Compilation
***********

C code: make

Web App: npm run dev (39354 OR 31817)


*****************
Known Limitations
*****************

- For some reason, my createGEDCOM function will make the web application crash, which means the only backend functionality
  I could implement was uploading the file, and creating a simple GEDCOM
  
 - For the file upload, there is one button that brings up a file browser for you to select the file you wish to upload, and it will
   automatically send that file to the server for you after double clicking or pressing open
