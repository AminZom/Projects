*******************************************
Mohammadamin Sheikhtaheri           0930853
CIS2750         			   Assignment 4
Sunday April 1, 2018
*******************************************

***********
Compilation
***********

C code: make

Web App: npm run dev (39354 OR 31817)


*****************
Known Limitations
*****************

- The file upload button does not work, please place the files inside the "Uploads" folder, and refresh the page, they will show up
  inside the file log panel
  
- The manual SELECT SQL statement does not print anything to the results table, instead it will print it to the web console which is
  accessible by clicking F12
